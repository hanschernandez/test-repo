module.exports = {
  presets: ['./babel-preset.js']
}
