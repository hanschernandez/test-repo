**The documentation has been moved to [styled-components.com](https://styled-components.com/docs/api), please update your bookmarks!**
