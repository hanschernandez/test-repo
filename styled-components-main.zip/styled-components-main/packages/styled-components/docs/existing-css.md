**The documentation has been moved to [styled-components.com](https://www.styled-components.com/docs/advanced#existing-css), please update your bookmarks!**
