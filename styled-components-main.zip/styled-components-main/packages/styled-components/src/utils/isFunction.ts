export default function isFunction(test: any) {
  return typeof test === 'function';
}
